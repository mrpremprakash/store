<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use Validator;
use App\Shop;
use App\Shop_keywords;
use App\Cities;
use Illuminate\Support\Facades\Input;

class StoreController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $input_type = Input::get('type');
        $keyword = Input::get('keyword');
        $query = "MATCH (address) AGAINST ('$keyword')";
        // $query looks like 
        // MATCH (first_name, last_name, email) AGAINST ('+jar* +eitni*' IN BOOLEAN MODE)

        $shop = Shop::whereRaw($query)->get();
        $res_count= $shop->count();
        $result = $shop->toArray();
        return response()->json([
                    'status' => 'success',
                    'count' =>$res_count,
                    'result' => $result
        ]);
    }
    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $shop = Shop::count();
        $Cities = Cities::select('city_id', 'city_name')->get();
        return view('store.add',  compact('Cities','shop'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $messages = [
            'store_name.required' => 'Name is required',
            'store_city.required' => 'City is required',
        ];
        $validator = Validator::make($request->all(), [
            'store_name' => 'required',
            'store_city' => 'required',
        ], $messages);

        if ($validator->fails()) {
            return redirect('store/create')
                        ->withErrors($validator)
                        ->withInput();
        }
        $name_string = str_replace(' ', '-', strtolower($request->store_name))."-".str_replace(' ', '-', strtolower($request->city_name));
        
        $check_slug = Shop::where('slug','=',$name_string)->count();
        $max_slug_id = Shop::max('id');
        if($check_slug!=0){
            $name_string = $name_string."_".$max_slug_id;
        }
        $latlong=array(0,0);
        $latlong=  explode(',', $request->lat_long);
        
        $Shop = new Shop;

        $Shop->name = $request->store_name;
        $Shop->slug = $name_string;
        $Shop->city_id = $request->store_city;
        $Shop->address = $request->store_address;
        $Shop->zip_code = $request->store_zip;
        $Shop->primary_phone_no = $request->primary_phone_no;
        $Shop->alternate_phone_no = $request->alternate_phone_no;
        $Shop->latitude = $latlong[0];
        $Shop->longitude = $latlong[1];
        $Shop->email_id = $request->email_id;
        $Shop->created_at = date('Y-m-d H:i:s');
        $Shop->updated_at =  date('Y-m-d H:i:s');
        
    if($Shop->save()){
        if($request->keywords){
            $keywords=  explode(',', $request->keywords);
            $keyword_arr=array();
            foreach ($keywords as $keyword_val){
                $keyword_arr[]=array(
                    'name'=>$keyword_val,
                    "shop_id"=>$Shop->id,
                    'created_at'=>date('Y-m-d H:i:s'),
                    'updated_at'=>date('Y-m-d H:i:s')
                );
            }
            $keyword_res = Shop_keywords::insert($keyword_arr);
        }
        $request->session()->flash('alert-success', 'Shop added successfully!');
        return redirect()->route("store.create");
    }
    else{
        $request->session()->flash('alert-danger', 'Unable to add Shop!');
        return redirect()->route("store.create");
    }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
