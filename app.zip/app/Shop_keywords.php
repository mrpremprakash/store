<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shop_keywords extends Model
{
    protected $table = 'shop_keywords';
}
