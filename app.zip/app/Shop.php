<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shop extends Model
{
    protected $table = 'shop';
    protected $fillable = [
        'name', 
        'address', 
        'city_id',
        'zip_code',
        'slug',
        'latitude',
        'longitude',
        'primary_phone_no',
        'alternate_phone_no',
        'email_id',
        'created_at',
        'updated_at',
    ];
}
